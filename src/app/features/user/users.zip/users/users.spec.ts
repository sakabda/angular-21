import { describe, it, expect, beforeEach, vi } from 'vitest';
import { TestBed, ComponentFixture } from '@angular/core/testing';

import { Users } from './users';
import { UsersStore } from '../data/users.store';
import { MatDialog } from '@angular/material/dialog';
import { MatSnackBar } from '@angular/material/snack-bar';

// Angular test environment
import {
  BrowserDynamicTestingModule,
  platformBrowserDynamicTesting,
} from '@angular/platform-browser-dynamic/testing';

TestBed.initTestEnvironment(BrowserDynamicTestingModule, platformBrowserDynamicTesting());

// ---------------- MOCK STORES ----------------
class MockUsersStore {
  loadUsers = vi.fn();
  createUser = vi.fn().mockReturnValue({
    subscribe: (fn: any) => fn(),
  });
  updateUser = vi.fn().mockReturnValue({
    subscribe: (fn: any) => fn(),
  });
  deleteUser = vi.fn().mockReturnValue({
    subscribe: (fn: any) => fn(),
  });
}

// ---------------- MOCK DIALOG ----------------
class MockDialog {
  open = vi.fn().mockReturnValue({
    afterClosed: () => ({
      subscribe: (fn: any) => fn(true), // simulate confirming dialog
    }),
  });
}

// ---------------- MOCK SNACKBAR ----------------
class MockSnackBar {
  open = vi.fn();
}

// ---------------- BEGIN TESTS ----------------
describe('Users Component', () => {
  let fixture: ComponentFixture<Users>;
  let component: Users;
  let store: MockUsersStore;

  beforeEach(async () => {
    store = new MockUsersStore();

    await TestBed.configureTestingModule({
      imports: [Users],
      providers: [
        { provide: UsersStore, useValue: store },
        { provide: MatDialog, useClass: MockDialog },
        { provide: MatSnackBar, useClass: MockSnackBar },
      ],
    }).compileComponents();

    fixture = TestBed.createComponent(Users);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  // ----------- TEST INITIALIZATION -----------
  it('should create component', () => {
    expect(component).toBeTruthy();
  });

  it('should load users on init', () => {
    expect(store.loadUsers).toHaveBeenCalled();
  });

  // ----------- TEST OPEN DELETE -----------
  it('should delete user when openDelete is called', () => {
    const user = { id: 1, firstName: 'John' };

    component.openDelete(user);

    expect(store.deleteUser).toHaveBeenCalledWith(1);
  });
});
